import React, { Component } from 'react';
import './style.css';

export class Footer extends Component {
  render() {
    return (
      <footer>Copyright © 2020 Genetech. All Rights Reserved</footer>
    )
  }
}

export default Footer;
