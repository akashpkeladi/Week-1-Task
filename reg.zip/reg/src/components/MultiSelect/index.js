import MultiSelect from './MultiSelect';

export default MultiSelect;
