import ProfileImage from './ProfileImage';

export default ProfileImage;
