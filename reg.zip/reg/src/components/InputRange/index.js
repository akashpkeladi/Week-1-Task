import InputRange from './InputRange';

export default InputRange;
