import Approval from './Approval';

export default Approval;
